- Hatsune Miku Recycle Bin -

Icons created by the amazing "DevanAlbarnEvans"
Installer and zip archive by "DJ-Zemar"

How to use:

To automatically install the icons, run "Installer-MikuBin.cmd" as Administrator and when prompted, enter the number 1.
The file should automatically do all the work for you.

To uninstall, simply use the same method as before, and this time enter the number 2.
If you delete this package, an extra installer will be added in "C:\Windows\MikuRecycleBin" for your convenience.

Deleting or modifying any files in this package before Installing or Uninstalling could potentially cause errors, so please refrain from doing so unless you know what you are doing.